<template>
    <h2 class="text-center my-5">Autores</h2>
<!-- formulario <form action=""></form>-->


<table class="table table-striped table-hover mb-5">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <tr v-for="autor in autores" :key="autor.id">
            <td>{{ autor.nombre }}</td>
            <td>
                <button class="btn btn-primary btn-sm">Editar</button>
                <button class="btn btn-danger btn-sm">Eliminar</button>
            </td>
        </tr>
    </tbody>

</table>

</template>

<script setup>
import { ref, onMounted } from 'vue'
import { getAutores } from '@/services/autorService';

const autores = ref([])

const cargarAutores = async () => {
try{
    autores.value = await getAutores()
} catch (error) {
    console.error('Error al cargar los autores', error)
}
}

onMounted(() => {
    cargarAutores()
})
</script>