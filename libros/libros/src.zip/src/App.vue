<template>
  <RouterView />  

</template>
  

<script setup>
</script>

<style scoped>
body{
  background-color: antiquewhite;
}
</style>
