import { createRouter, createWebHistory} from 'vue-router'
import AutoresView from '@/views/AutoresView.vue'

const router = createRouter({
history: createWebHistory(import.meta.env.BASE_URL),
routes: [
    {
        path: '/',
    },
    {
    path: '/autores',
    name: 'autores',
    component: AutoresView
    }
    ]
})

export default router