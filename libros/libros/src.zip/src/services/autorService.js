import { db } from '../firebase/firebase'
import {
    collection,
    getDocs,
    addDoc,
    updateDoc,
    deleteDoc,
    doc
}
from 'firebase/firestore'

const autoresCollection = collection(db, 'autores')

export const getAutores = async () => {
    const snapshot = await getDocs(autoresCollection)

    return snapshot.docs.map( doc => ({
        id: doc.id,
        ...doc.data()
    }))
}